<!doctype html>

<html lang="en">
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="stylesheet.css">
</head>

<body>

	<h1>Home Page</h1> 

	<?php include "nav_bar.php"; ?>

	<font size="50" color="Black"><p align ="center">Road traffic accidents</p></font>
	
</body>
</html>